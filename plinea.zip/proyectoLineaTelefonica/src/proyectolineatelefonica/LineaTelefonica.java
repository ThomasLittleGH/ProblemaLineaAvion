/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectolineatelefonica;

/**
 *
 * @author Lab
 */
public class LineaTelefonica {

    private int numeroLlamadas, numeroMinutos, costoLlamadas;

    public void inicializar() {
        numeroLlamadas = 0;
        numeroMinutos = 0;
        costoLlamadas = 0;
    }

    public int getNumeroLlamadas() {
        return numeroLlamadas;
    }

    public int getNumeroMinutos() {
        return numeroMinutos;
    }

    public int getCostoLlamadas() {
        return costoLlamadas;
    }

    public void agregarLlamadaLocal(int minutos) {
        costoLlamadas += minutos * 27;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

    public void agregarLlamadaInternacional(int minutos) {
        costoLlamadas += minutos * 250;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

    public void agregarLlamadaCelular(int minutos) {
        costoLlamadas += minutos * 130;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

}
