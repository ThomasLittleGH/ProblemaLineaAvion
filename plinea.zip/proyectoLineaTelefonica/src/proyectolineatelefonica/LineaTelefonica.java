/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectolineatelefonica;

/**
 *
 * @author Lab
 */
public class LineaTelefonica {
    // declaracion de variables
    private int numeroLlamadas, numeroMinutos, costoLlamadas;

    public void inicializar() {
        // Inicializo las variables
        numeroLlamadas = 0;
        numeroMinutos = 0;
        costoLlamadas = 0;
    }

    public int getNumeroLlamadas() {
        return numeroLlamadas;
    }

    public int getNumeroMinutos() {
        return numeroMinutos;
    }

    public int getCostoLlamadas() {
        return costoLlamadas;
    }

    public void agregarLlamadaLocal(int minutos) {
        // Al hacer una llamada agrego los valores previos a los preexistentes en los distintos ambitos (costo, minutos, n llamadas)
        costoLlamadas += minutos * 27;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

    public void agregarLlamadaInternacional(int minutos) {
        // Al hacer una llamada agrego los valores previos a los preexistentes en los distintos ambitos (costo, minutos, n llamadas)
        costoLlamadas += minutos * 250;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

    public void agregarLlamadaCelular(int minutos) {
        // Al hacer una llamada agrego los valores previos a los preexistentes en los distintos ambitos (costo, minutos, n llamadas)
        costoLlamadas += minutos * 130;
        numeroLlamadas++;
        numeroMinutos += minutos;
    }

}
