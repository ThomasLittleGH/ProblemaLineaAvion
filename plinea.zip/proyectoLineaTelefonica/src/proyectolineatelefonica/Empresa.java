/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectolineatelefonica;

/**
 *
 * @author Lab
 */
public class Empresa {

    LineaTelefonica linea1, linea2, linea3;

    public void inicializar() {
        linea1 = new LineaTelefonica();
        linea2 = new LineaTelefonica();
        linea3 = new LineaTelefonica();

        linea1.inicializar();
        linea2.inicializar();
        linea3.inicializar();
    }

    public LineaTelefonica darLinea(int linea) {
        switch (linea) {
            case 1:
                return linea1;
            case 2:
                return linea2;
            case 3:
                return linea3;
            default:
                return linea1;
        }
    }

    public void agregarLlamadaLocal(int linea, int minutos) {
        switch (linea) {
            case 1:
                linea1.agregarLlamadaLocal(minutos);
                break;
            case 2:
                linea2.agregarLlamadaLocal(minutos);
                break;
            case 3:
                linea3.agregarLlamadaLocal(minutos);
                break;
            default:
                break;
        }
    }

    public void agregarLlamadaInternacional(int linea, int minutos) {
        switch (linea) {
            case 1:
                linea1.agregarLlamadaInternacional(minutos);
                break;
            case 2:
                linea2.agregarLlamadaInternacional(minutos);
                break;
            case 3:
                linea3.agregarLlamadaInternacional(minutos);
                break;
            default:
                break;
        }
    }

    public void agregarLlamadaCelular(int linea, int minutos) {
        switch (linea) {
            case 1:
                linea1.agregarLlamadaCelular(minutos);
                break;
            case 2:
                linea2.agregarLlamadaCelular(minutos);
                break;
            case 3:
                linea3.agregarLlamadaCelular(minutos);
                break;
            default:
                break;
        }
    }

    public int darTotalNumeroLlamadas() {
        return linea1.getNumeroLlamadas() + linea2.getNumeroLlamadas() + linea3.getNumeroLlamadas();
    }

    public int darTotalMinutos() {
        return linea1.getNumeroMinutos() + linea2.getNumeroMinutos() + linea3.getNumeroMinutos();
    }

    public int darCostoPromedioMinutos() {
        // minutos partido en costo
        int costo = (linea1.getNumeroMinutos()+ linea2.getNumeroMinutos() + linea3.getNumeroMinutos());
        if (costo == 0){
            costo = 1;
        }
        return ((linea1.getCostoLlamadas() + linea2.getCostoLlamadas() + linea3.getCostoLlamadas()) / costo );
    }

    public void reiniciar() {
        linea1.inicializar();
        linea2.inicializar();
        linea3.inicializar();
    }
}
